const m=()=>{let n=document.getElementById("glasslm-floating-icon");if(n)return n;const e=document.createElement("div");e.id="glasslm-floating-icon",e.style.position="fixed",e.style.zIndex="2147483647",e.style.transition="opacity 0.2s ease";const t=e.attachShadow({mode:"open"}),s=chrome.runtime.getURL("glass_logo.jpg");t.innerHTML=`
        <style>
            :host {
                display: block;
                width: 32px;
                height: 32px;
            }
            .glasslm-crystal {
                width: 32px;
                height: 32px;
                /* Removed background/border as requested */
                background: transparent;
                border-radius: 8px; /* Keep radius for image clipping */
                display: flex;
                align-items: center;
                justify-content: center;
                /* Removed box-shadow and backdrop-filter */
                cursor: pointer;
                pointer-events: auto;
                animation: glasslm-float 3s ease-in-out infinite;
                transform: scale(0.9);
                transition: transform 0.2s ease;
            }
            .glasslm-crystal:hover {
                transform: scale(1.1);
                /* Add a subtle glow on hover only, or remove entirely if desired. keeping subtle for feedback */
                filter: drop-shadow(0 0 8px rgba(168, 85, 247, 0.6));
            }
            img {
                width: 100%;
                height: 100%;
                object-fit: cover;
                border: none;
                display: block;
                margin: 0;
                padding: 0;
                /* Ensure image shape */
                border-radius: 6px; 
            }
            @keyframes glasslm-float {
                0% { transform: translateY(0px) scale(1); }
                50% { transform: translateY(-3px) scale(1.05); }
                100% { transform: translateY(0px) scale(1); }
            }
        </style>
        <div class="glasslm-crystal">
            <img src="${s}" alt="GlassLM" />
        </div>
    `,document.documentElement.appendChild(e);const i=t.querySelector(".glasslm-crystal");return i&&i.addEventListener("click",r=>{var u;r.preventDefault(),r.stopPropagation();const f=o?o.value||o.innerText||o.textContent||"":((u=window.getSelection())==null?void 0:u.toString())||"";chrome.runtime.sendMessage({action:"openSidePanel",text:f})}),e};let l=m(),o=null,a=null;const p=new MutationObserver(()=>{document.getElementById("glasslm-floating-icon")||(l=m())});p.observe(document.documentElement,{childList:!0,subtree:!1});function g(n){let e=n,t=0;for(;e&&e!==document.body&&t<5;){const s=e.isContentEditable||e.getAttribute("contenteditable")==="true"||e.getAttribute("role")==="textbox",i=e.tagName==="INPUT"&&["text","search","email","url","tel","password"].includes(e.type),r=e.tagName==="TEXTAREA";if(s||i||r)return e;e=e.parentElement,t++}return null}const d=n=>{if(!n)return;const e=g(n);if(e){o=e,c(e);const t=document.getElementById("glasslm-floating-icon");t&&(t.style.opacity="1",t.style.pointerEvents="auto"),a&&clearInterval(a),a=window.setInterval(()=>{o&&o.isConnected?c(o):(t&&(t.style.opacity="0",t.style.pointerEvents="none"),a&&clearInterval(a))},100)}};document.addEventListener("focusin",n=>d(n.target),!0);document.addEventListener("click",n=>d(n.target),!0);document.addEventListener("keyup",n=>d(n.target),!0);document.addEventListener("focusout",n=>{setTimeout(()=>{const e=document.activeElement,t=document.getElementById("glasslm-floating-icon");e!==o&&(!o||!o.contains(e))&&(t&&(t.style.opacity="0",t.style.pointerEvents="none"),o=null,a&&clearInterval(a))},200)});function c(n){if(!n.offsetParent&&n!==document.body)return;const e=n.getBoundingClientRect();let t=e.top+10;e.height<40&&(t=e.top+e.height/2-16),t<0&&(t=e.top);let s=e.right-45;s>window.innerWidth-45&&(s=window.innerWidth-45),l.style.top=`${t}px`,l.style.left=`${s}px`}const y=new MutationObserver(n=>{o&&c(o)});y.observe(document.body,{childList:!0,subtree:!0,attributes:!0});chrome.runtime.onMessage.addListener((n,e,t)=>{var s;if(n.action==="getText"){let i="";if(o)i=o.value||o.innerText||o.textContent||"";else if(document.activeElement){const r=g(document.activeElement);r?i=r.value||r.innerText||r.textContent||"":i=((s=window.getSelection())==null?void 0:s.toString())||""}t({text:i})}return!0});console.log("GlassLM Content Script Loaded");
